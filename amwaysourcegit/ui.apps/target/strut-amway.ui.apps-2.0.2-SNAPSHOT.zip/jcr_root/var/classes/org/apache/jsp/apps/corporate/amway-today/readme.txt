Resolve that JSPs don't always recompile after a code package installation
