/* Strut-amway javascript */
