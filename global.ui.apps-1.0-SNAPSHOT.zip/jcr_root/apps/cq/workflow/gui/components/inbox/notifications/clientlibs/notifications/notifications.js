/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function($, wf) {
    "use strict";

    var ns = "notification-list";
var ui = $(window).adaptTo("foundation-ui");

    var bail = false;

    $(document).off("foundation-contentloaded." + ns);
    $(document).on("foundation-contentloaded." + ns, function() {

        if (bail) {
            return;
        }
        bail = true;

        //build a view that uses the notifications collection
        var $collection = $('.foundation-collection.cq-inbox-notifications');
        if ($collection.length > 0) {
            console.log("inside");
            var inbox_view = new wf.view.InboxListView({

                el: $collection,
                emptyEl: $('.page .content .no-items-banner'),
                collection: wf.domain.InboxItemCollection.getInstance()
            });
        }



    });

    $(document).fipo("tap.cq-inbox-item-activator", "click.cq-inbox-item-activator", ".list .card-page .select ~ a", function(e) {
        var $target = $(e.target);
        if (!$target.hasClass("payload-href")) {
            e.preventDefault();
            return;
        }
    });


//calling to rejection workflow.
$(document).on("click", ".cq-button-primary-reject", function(e) {
var workflowWorkItem = $('.workitem-path').attr("data-workitem-path");
// need to be fixed : var test = $('*[data-workitem-path]');
 var model = "/etc/workflow/models/auspost-global-activate-workflow/jcr:content/model";
 var paths = "";
 auspostWorkflowTrigger_reject(paths, "", model,workflowWorkItem);
});

// Auspost custom workflow for ourpost and global projects
    function auspostWorkflowTrigger_reject(paths, startComment, model,workflowWorkItem) {
        var admin = this;
        var startComment = startComment;
        var params = {
            "_charset_":"UTF-8",
            "model":model,
            "payload":paths,
            "payloadType":"JCR_PATH",
            "startComment":startComment,
            "actionRequested":"reject",
            "workflowWorkItem":workflowWorkItem
        };

        $.ajax({
        	   url: '/etc/workflow/instances',
        	   async: false,
        	   data: {
        		   "_charset_":"UTF-8",
        	        "model":model,
        	        "payload":paths,
        	        "payloadType":"JCR_PATH",
        	        "startComment":startComment,
        	        "actionRequested":"reject",
                    "workflowWorkItem":workflowWorkItem
        	   },
        	   error: function() {
        	     alert('Error, Please contact the admin !!!');
        	   },
        	   success: function(data) {

        		   ui.notify(null, Granite.I18n.get("Request for page publication has been forwarded for an approval workflow"));
        		   setTimeout(location.reload(), 5000);


        	   },
        	   type: 'POST'
        	});


    };

})(Granite.$, Granite.Workflow);
