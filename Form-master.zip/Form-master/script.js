var teamDetail = {
	"teamName": "null",
	"location": "null",
	"class": "null",
	"manager": 0,
	"member_list": []
}


var output = document.getElementById('output');


document.getElementById("send").addEventListener("click", capture);
document.getElementById("add").addEventListener("click", add);

function capture() {
	console.log(document.getElementById('tName').value);
	teamDetail.teamName = document.getElementById('tName').value;
	teamDetail.location = document.getElementById('loc').value;
	teamDetail.class = document.getElementById('class').value;
	teamDetail.manager = document.getElementById('manager').value;


	console.log(teamDetail);

}

function add(){
	var search_member = document.getElementById('search_member');
	var member_list = document.getElementById('member_list');
	var a = document.createElement('a');
	a.setAttribute('href','#');
	a.setAttribute('class',"list-group-item");

	a.innerHTML = search_member.value + "  - Name " + " - Designation";
	member_list.appendChild(a);

	var manager = document.getElementById('manager');
	var option = document.createElement('option');
	option.innerHTML = search_member.value;
	manager.appendChild(option);
}
